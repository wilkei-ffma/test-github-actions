USE master ;  
GO  
DROP DATABASE [jira-prod] ;  
GO